#!/bin/bash

set -e

# Hardcoded environment variables
GO_BINARY_NAME="jseaidev"
DOCKER_IMAGE_NAME="ghcr.io/koushikcodeswebpages/jseaidev:latest"
PAT_TOKEN="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"
GITHUB_USERNAME="KoushikCodesWebpages"  # Your GitHub username
SSH_PASSWORD="HHA27may@2017"
VPS_IP="168.231.109.75"
VPS_USER="root"

# Check that required variables are set
if [ -z "$GO_BINARY_NAME" ]; then
  echo "Error: GO_BINARY_NAME is not set."
  exit 1
fi

if [ -z "$DOCKER_IMAGE_NAME" ]; then
  echo "Error: DOCKER_IMAGE_NAME is not set."
  exit 1
fi

if [ -z "$PAT_TOKEN" ]; then
  echo "Error: PAT_TOKEN is not set."
  exit 1
fi

if [ -z "$GITHUB_USERNAME" ]; then
  echo "Error: GITHUB_USERNAME is not set."
  exit 1
fi

# All environment variables are loaded successfully, so print confirmation with emojis
echo "All environment variables are loaded successfully! 🎉"
echo "GO_BINARY_NAME: $GO_BINARY_NAME 🚀"
echo "DOCKER_IMAGE_NAME: $DOCKER_IMAGE_NAME 🐳"
echo "PAT_TOKEN: $PAT_TOKEN 🔑"
echo "GITHUB_USERNAME: $GITHUB_USERNAME 👨‍💻"

# Remove the previous Docker image if it exists
echo "Removing previous Docker image if it exists... 🧹"
docker rmi -f $DOCKER_IMAGE_NAME || echo "No previous image found to remove. ❌"

# BUILD GO APP
echo "Building the Go binary... 💻"
CGO_ENABLED=0 go build -o $GO_BINARY_NAME .

# BUILD IMAGE
echo "Building the Docker image... 🖼️"
docker build -t $DOCKER_IMAGE_NAME .

# LOGIN GHDR
echo "Logging into GitHub Docker registry... 🔐"
echo $PAT_TOKEN | docker login ghcr.io -u $GITHUB_USERNAME --password-stdin

# PUSH IMAGE
echo "Pushing the Docker image to GitHub registry... 🚀"
docker push $DOCKER_IMAGE_NAME

# GIT PUSH
echo "Adding, committing, and pushing code to GitHub... 📦"
git add .
git commit -m "Add binary, Dockerfile, and push to GitHub registry"
git push origin dev

# DONE
echo "Build and push completed successfully! 🎉"
